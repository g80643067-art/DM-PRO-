# DmFirst Linked Frontend Demo

This is a static frontend demo rebuilt from the supplied extracted HTML snapshots.

## Open in VS Code
1. Extract this ZIP.
2. Open the folder in VS Code.
3. Open `index.html` with Live Server, or double-click it in a browser.
4. Use the bottom DEMO navigation to move between pages.

## Pages
Home, Popular, Activity, Account, Casino, Fishing, Lottery, Mini Games, Promotion, PVC, Slots, Spin Wheel.

## Important
This version removes the original external runtime/API scripts and keeps the pages as a frontend-only demo. Navigation between local HTML pages is wired up. It does not include real-money, payment, betting, wallet, or backend functionality. Some original remote images may still require an internet connection because the supplied extraction did not contain those image files locally.
