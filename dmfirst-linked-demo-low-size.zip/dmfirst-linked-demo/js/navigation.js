(function(){
  const pages={
    "home":"index.html","popular":"popular.html","activity":"activity.html","account":"account.html",
    "casino":"casino.html","fishing":"fishing.html","lottery":"lottery.html","mini games":"mini-games.html",
    "promotion":"promotion.html","pvc":"pvc.html","slots":"slots.html","spin wheel":"spin-wheel.html"
  };
  const normalize=s=>s.toLowerCase().replace(/\s+/g," ").trim();
  document.addEventListener("click",function(e){
    if(e.defaultPrevented) return;
    const target=e.target.closest("a,button,[role=button],.game-tabs__scroll-item,.tabbar__items-tab");
    if(!target) return;
    if(target.closest(".demo-navigation")) return;
    const text=normalize(target.innerText||target.textContent||"");
    for(const key of Object.keys(pages)){
      if(text===key || text.startsWith(key+" ")){
        e.preventDefault(); e.stopPropagation(); window.location.href=pages[key]; return;
      }
    }
  },true);
  const current=location.pathname.split("/").pop()||"index.html";
  document.querySelectorAll(".demo-navigation a").forEach(a=>{if(a.getAttribute("href")===current)a.classList.add("active")});
})();
